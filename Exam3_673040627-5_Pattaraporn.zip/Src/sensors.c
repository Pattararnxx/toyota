/***********************************************************************
 * File Name    : sensors.c
 * Description  : Converts raw ADC readings into physical units.
 *                  - Temperature from an NTC thermistor (Beta equation)
 *                  - Light intensity from an LDR (log-log model)
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "sensors.h"
#include "adc.h"
#define STM32F411xE
#include "stm32f4xx.h"
#include <math.h>

/* Private define ----------------------------------------------------*/
#define SENSOR_VREF          (3.3f)
#define SENSOR_VCC            (3.3f)
#define SENSOR_ADC_MAXRES     (4095.0f)
#define SENSOR_KELVIN_OFFSET  (273.15f)
#define SENSOR_MILLI_SCALE    (1000.0f)

/* NTC (temperature) constants */
#define NTC_RX     (10000.0f)
#define NTC_R0     (10000.0f)
#define NTC_T0     (298.15f)   /* 25 degC in Kelvin */
#define NTC_BETA   (3950.0f)

/* LDR (light) constants */
#define LDR_RX      (10000.0f)
#define LDR_SLOPE   (-0.6875f)
#define LDR_OFFSET  (5.1276f)

#define FPU_CPACR_FULL_ACCESS (0xFu)
#define FPU_CPACR_SHIFT       (20u)

/* Private function prototype -----------------------------------------*/
static float sensors_adc_to_voltage(uint16_t u2_adcValue);

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - sensors_init
 * @brief   - Enable the FPU so floating-point math (used by the
 *            sensor formulas) runs on hardware.
 * @param   - void
 * @return  - void
 ************************************************************************/
void sensors_init(void)
{
    SCB->CPACR |= (FPU_CPACR_FULL_ACCESS << FPU_CPACR_SHIFT);
    __asm volatile ("dsb");
    __asm volatile ("isb");
}

/***********************************************************************
 * @fn      - sensors_read_temperature_millidegC
 * @brief   - Read the NTC thermistor and compute the temperature using
 *            the Beta equation.
 * @param   - void
 * @return  - int32_t : temperature in milli-degrees Celsius
 ************************************************************************/
int32_t sensors_read_temperature_millidegC(void)
{
    uint16_t u2t_adcValue = adc_read_channel(ADC_CH_TEMPERATURE);
    float f4t_voltage = sensors_adc_to_voltage(u2t_adcValue);
    float f4t_resistance = NTC_RX * f4t_voltage / (SENSOR_VCC - f4t_voltage);
    float f4t_temperatureC = ((NTC_BETA * NTC_T0) /
                               (NTC_T0 * logf(f4t_resistance / NTC_R0) + NTC_BETA)) -
                              SENSOR_KELVIN_OFFSET;

    return (int32_t)(f4t_temperatureC * SENSOR_MILLI_SCALE);
}

/***********************************************************************
 * @fn      - sensors_read_light_lux
 * @brief   - Read the LDR and compute the light intensity in Lux using
 *            the log-log model.
 * @param   - void
 * @return  - uint16_t : light intensity in Lux
 ************************************************************************/
uint16_t sensors_read_light_lux(void)
{
    uint16_t u2t_adcValue = adc_read_channel(ADC_CH_LIGHT);
    float f4t_voltage = sensors_adc_to_voltage(u2t_adcValue);
    float f4t_resistance = LDR_RX * f4t_voltage / (SENSOR_VREF - f4t_voltage);
    float f4t_lux = powf(10.0f, (log10f(f4t_resistance) - LDR_OFFSET) / LDR_SLOPE);

    return (uint16_t)f4t_lux;
}

/* Private functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - sensors_adc_to_voltage
 * @brief   - Convert a raw 12-bit ADC reading into a voltage.
 * @param   - u2_adcValue : raw 12-bit ADC reading, range 0-4095
 * @return  - float : voltage in volts
 ************************************************************************/
static float sensors_adc_to_voltage(uint16_t u2_adcValue)
{
    return ((float)u2_adcValue * SENSOR_VREF) / SENSOR_ADC_MAXRES;
}
