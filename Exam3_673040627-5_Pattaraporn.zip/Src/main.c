/***********************************************************************
 * File Name    : main.c
 * Description  : Exam3 - UART command interface.
 *                  'F' -> LEDs off, print "LED OFF"
 *                  'O' -> LEDs on,  print "LED ON"
 *                  'T' -> print current temperature
 *                  'l' -> print current light intensity
 *                  any other character -> print "Not Response\n"
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#define STM32F411xE
#include "stm32f4xx.h"
#include "uart.h"
#include "adc.h"
#include "sensors.h"
#include "leds.h"
#include <stdio.h>

/* Private define ----------------------------------------------------*/
#define CMD_LED_OFF          ('F')
#define CMD_LED_ON           ('O')
#define CMD_READ_TEMPERATURE ('T')
#define CMD_READ_LIGHT       ('l')
#define MSG_BUFFER_SIZE      (50u)

/* Private function prototype -----------------------------------------*/
static void system_init(void);
static void handle_command(uint8_t u1_command);

/***********************************************************************
 * @fn      - main
 * @brief   - Program entry point. Waits for one character over UART
 *            and dispatches it to the matching action.
 * @param   - void
 * @return  - int : never returns
 ************************************************************************/
int main(void)
{
    uint8_t u1t_command;

    system_init();

    while (1)
    {
        u1t_command = uart_receive_char();
        handle_command(u1t_command);
    }
}

/***********************************************************************
 * @fn      - system_init
 * @brief   - Initialise all peripherals used in this program.
 * @param   - void
 * @return  - void
 ************************************************************************/
static void system_init(void)
{
    uart_init();
    adc_init();
    sensors_init();
    leds_init();
}

/***********************************************************************
 * @fn      - handle_command
 * @brief   - Execute the action associated with one received command
 *            character and print the matching response over UART.
 * @param   - u1_command : received command character
 * @return  - void
 ************************************************************************/
static void handle_command(uint8_t u1_command)
{
    char ac_msgBuffer[MSG_BUFFER_SIZE];
    int32_t s4t_temperature;
    uint16_t u2t_light;

    switch (u1_command)
    {
        case CMD_LED_OFF:
            leds_turn_off();
            uart_send_string("LED OFF");
            break;

        case CMD_LED_ON:
            leds_turn_on();
            uart_send_string("LED ON");
            break;

        case CMD_READ_TEMPERATURE:
            s4t_temperature = sensors_read_temperature_millidegC();
            (void)sprintf(ac_msgBuffer, "Temperature = %ld millidegree Celcius\n",
                          (long)s4t_temperature);
            uart_send_string(ac_msgBuffer);
            break;

        case CMD_READ_LIGHT:
            u2t_light = sensors_read_light_lux();
            (void)sprintf(ac_msgBuffer, "Light intensity = %u Lux\n",
                          (unsigned int)u2t_light);
            uart_send_string(ac_msgBuffer);
            break;

        default:
            uart_send_string("Not Response\n");
            break;
    }
}
