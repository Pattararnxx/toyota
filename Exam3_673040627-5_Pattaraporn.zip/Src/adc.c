/***********************************************************************
 * File Name    : adc.c
 * Description  : ADC1 polling driver. Both analog inputs used in this
 *                program (NTC temperature sensor on PA0/channel 0 and
 *                LDR light sensor on PA1/channel 1) are configured as
 *                analog pins at init time; the regular sequence is
 *                re-pointed to the requested channel on every read.
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "adc.h"

/* Private define ----------------------------------------------------*/
#define ADC_MODER_BITS_PER_PIN (2u)
#define ADC_MODE_ANALOG      (0x3u)
#define ADC_SAMPLE_TIME_LONG (0x7u)
#define ADC_SMPR2_BITS_PER_CH (3u)
#define ADC_SQR1_SINGLE_CONV  (0u)

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - adc_init
 * @brief   - Enable clocks, configure PA0 and PA1 as analog inputs and
 *            configure ADC1 for single-conversion regular mode with a
 *            long sample time on both channels.
 * @param   - void
 * @return  - void
 ************************************************************************/
void adc_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

    GPIOA->MODER |= (ADC_MODE_ANALOG << (ADC_CH_TEMPERATURE * ADC_MODER_BITS_PER_PIN));
    GPIOA->MODER |= (ADC_MODE_ANALOG << (ADC_CH_LIGHT * ADC_MODER_BITS_PER_PIN));

    ADC1->CR2 &= ~ADC_CR2_CONT;
    ADC1->SMPR2 |= (ADC_SAMPLE_TIME_LONG << (ADC_CH_TEMPERATURE * ADC_SMPR2_BITS_PER_CH));
    ADC1->SMPR2 |= (ADC_SAMPLE_TIME_LONG << (ADC_CH_LIGHT * ADC_SMPR2_BITS_PER_CH));
    ADC1->SQR1 &= ~ADC_SQR1_L;
    ADC1->SQR1 |= (ADC_SQR1_SINGLE_CONV << ADC_SQR1_L_Pos);

    ADC1->CR2 |= ADC_CR2_ADON;
}

/***********************************************************************
 * @fn      - adc_read_channel
 * @brief   - Point the regular sequence at the given channel, start a
 *            conversion, wait for completion and return the result.
 * @param   - u1_channel : ADC input channel number (0-18)
 * @return  - uint16_t : conversion result, range 0-4095
 ************************************************************************/
uint16_t adc_read_channel(uint8_t u1_channel)
{
    ADC1->SQR3 &= ~ADC_SQR3_SQ1;
    ADC1->SQR3 |= ((uint32_t)u1_channel << ADC_SQR3_SQ1_Pos);

    ADC1->CR2 |= ADC_CR2_SWSTART;
    while ((ADC1->SR & ADC_SR_EOC) == 0u)
    {
        /* wait until conversion is complete */
    }
    return (uint16_t)ADC1->DR;
}

/* Private functions ----------------------------------------------------*/
