/***********************************************************************
 * File Name    : leds.c
 * Description  : Controls the Blue, Red and Yellow status LEDs as a
 *                group (all on / all off together, per UART command).
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "leds.h"
#include "gpio.h"

/* Private define ----------------------------------------------------*/
#define LED_BLUE_PORT   GPIOA
#define LED_BLUE_PIN    (5u)   /* PA5 -> Blue LED */
#define LED_RED_PORT    GPIOB
#define LED_RED_PIN     (6u)   /* PB6 -> Red LED */
#define LED_YELLOW_PORT GPIOA
#define LED_YELLOW_PIN  (7u)   /* PA7 -> Yellow LED */

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - leds_init
 * @brief   - Enable clocks and configure the 3 LED pins as outputs,
 *            starting in the OFF state.
 * @param   - void
 * @return  - void
 ************************************************************************/
void leds_init(void)
{
    RCC->AHB1ENR |= (RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN);

    gpio_set_output(LED_BLUE_PORT, LED_BLUE_PIN);
    gpio_set_output(LED_RED_PORT, LED_RED_PIN);
    gpio_set_output(LED_YELLOW_PORT, LED_YELLOW_PIN);

    leds_turn_off();
}

/***********************************************************************
 * @fn      - leds_turn_on
 * @brief   - Turn Blue, Red and Yellow LEDs ON.
 * @param   - void
 * @return  - void
 ************************************************************************/
void leds_turn_on(void)
{
    gpio_write(LED_BLUE_PORT, LED_BLUE_PIN, 1u);
    gpio_write(LED_RED_PORT, LED_RED_PIN, 1u);
    gpio_write(LED_YELLOW_PORT, LED_YELLOW_PIN, 1u);
}

/***********************************************************************
 * @fn      - leds_turn_off
 * @brief   - Turn Blue, Red and Yellow LEDs OFF.
 * @param   - void
 * @return  - void
 ************************************************************************/
void leds_turn_off(void)
{
    gpio_write(LED_BLUE_PORT, LED_BLUE_PIN, 0u);
    gpio_write(LED_RED_PORT, LED_RED_PIN, 0u);
    gpio_write(LED_YELLOW_PORT, LED_YELLOW_PIN, 0u);
}

/* Private functions ----------------------------------------------------*/
