/***********************************************************************
 * File Name    : gpio.c
 * Description  : Generic GPIO helper functions (register-level access).
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "gpio.h"

/* Private define ----------------------------------------------------*/
#define GPIO_MODER_BITS_PER_PIN  (2u)
#define GPIO_MODE_MASK           (0x3u)
#define GPIO_MODE_OUTPUT         (0x1u)
#define GPIO_MODE_INPUT          (0x0u)
#define GPIO_PUPDR_BITS_PER_PIN  (2u)
#define GPIO_PUPD_MASK           (0x3u)
#define GPIO_PUPD_PULLUP         (0x1u)

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - gpio_set_output
 * @brief   - Configure one pin as push-pull output, low speed.
 * @param   - px_port : GPIO port base address (e.g. GPIOA)
 *           - u1_pin  : pin number (0-15)
 * @return  - void
 ************************************************************************/
void gpio_set_output(GPIO_TypeDef *px_port, uint8_t u1_pin)
{
    uint32_t u4t_shift = (uint32_t)u1_pin * GPIO_MODER_BITS_PER_PIN;

    px_port->MODER &= ~(GPIO_MODE_MASK << u4t_shift);
    px_port->MODER |= (GPIO_MODE_OUTPUT << u4t_shift);
    px_port->OTYPER &= ~(1u << u1_pin);
    px_port->OSPEEDR &= ~(GPIO_MODE_MASK << u4t_shift);
}

/***********************************************************************
 * @fn      - gpio_set_input_pullup
 * @brief   - Configure one pin as input with internal pull-up resistor.
 * @param   - px_port : GPIO port base address (e.g. GPIOB)
 *           - u1_pin  : pin number (0-15)
 * @return  - void
 ************************************************************************/
void gpio_set_input_pullup(GPIO_TypeDef *px_port, uint8_t u1_pin)
{
    uint32_t u4t_moder_shift = (uint32_t)u1_pin * GPIO_MODER_BITS_PER_PIN;
    uint32_t u4t_pupdr_shift = (uint32_t)u1_pin * GPIO_PUPDR_BITS_PER_PIN;

    px_port->MODER &= ~(GPIO_MODE_MASK << u4t_moder_shift);
    px_port->PUPDR &= ~(GPIO_PUPD_MASK << u4t_pupdr_shift);
    px_port->PUPDR |= (GPIO_PUPD_PULLUP << u4t_pupdr_shift);
}

/***********************************************************************
 * @fn      - gpio_write
 * @brief   - Set or reset one output pin using BSRR (atomic write).
 * @param   - px_port  : GPIO port base address
 *           - u1_pin   : pin number (0-15)
 *           - u1_value : 0 = reset (LOW), non-zero = set (HIGH)
 * @return  - void
 ************************************************************************/
void gpio_write(GPIO_TypeDef *px_port, uint8_t u1_pin, uint8_t u1_value)
{
    if (u1_value != 0u)
    {
        px_port->BSRR = (1u << u1_pin);
    }
    else
    {
        px_port->BSRR = (1u << ((uint32_t)u1_pin + 16u));
    }
}

/* Private functions ----------------------------------------------------*/
