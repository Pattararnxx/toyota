/***********************************************************************
 * File Name    : uart.c
 * Description  : USART2 (PA2 = TX, PA3 = RX) polling driver used as
 *                the command channel to the PC (via ST-Link VCP).
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "uart.h"

/* Private define ----------------------------------------------------*/
#define UART_TX_PIN        (2u)   /* PA2 -> USART2_TX */
#define UART_RX_PIN        (3u)   /* PA3 -> USART2_RX */
#define UART_AF_USART2     (0x7u)
#define UART_MODER_BITS_PER_PIN (2u)
#define UART_MODE_ALT_FUNC (0x2u)
#define UART_AFR_BITS_PER_PIN (4u)
#define UART_BRR_115200_AT_16MHZ (139u)

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - uart_init
 * @brief   - Configure PA2/PA3 as USART2 alternate function pins and
 *            initialise USART2 for 115200 8N1, TX and RX enabled.
 * @param   - void
 * @return  - void
 ************************************************************************/
void uart_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    GPIOA->MODER &= ~((0x3u << (UART_TX_PIN * UART_MODER_BITS_PER_PIN)) |
                       (0x3u << (UART_RX_PIN * UART_MODER_BITS_PER_PIN)));
    GPIOA->MODER |= ((UART_MODE_ALT_FUNC << (UART_TX_PIN * UART_MODER_BITS_PER_PIN)) |
                      (UART_MODE_ALT_FUNC << (UART_RX_PIN * UART_MODER_BITS_PER_PIN)));

    GPIOA->AFR[0] &= ~((0xFu << (UART_TX_PIN * UART_AFR_BITS_PER_PIN)) |
                        (0xFu << (UART_RX_PIN * UART_AFR_BITS_PER_PIN)));
    GPIOA->AFR[0] |= ((UART_AF_USART2 << (UART_TX_PIN * UART_AFR_BITS_PER_PIN)) |
                       (UART_AF_USART2 << (UART_RX_PIN * UART_AFR_BITS_PER_PIN)));

    USART2->CR1 |= USART_CR1_UE;
    USART2->CR1 &= ~USART_CR1_M;
    USART2->CR2 &= ~USART_CR2_STOP;
    USART2->BRR = UART_BRR_115200_AT_16MHZ;
    USART2->CR1 |= (USART_CR1_TE | USART_CR1_RE);
}

/***********************************************************************
 * @fn      - uart_receive_char
 * @brief   - Block until one byte is received and return it.
 * @param   - void
 * @return  - uint8_t : received byte
 ************************************************************************/
uint8_t uart_receive_char(void)
{
    while ((USART2->SR & USART_SR_RXNE) == 0u)
    {
        /* wait until data received */
    }
    return (uint8_t)USART2->DR;
}

/***********************************************************************
 * @fn      - uart_send_char
 * @brief   - Send one byte, blocking until the TX buffer is free.
 * @param   - u1_data : byte to send
 * @return  - void
 ************************************************************************/
void uart_send_char(uint8_t u1_data)
{
    while ((USART2->SR & USART_SR_TXE) == 0u)
    {
        /* wait until TX buffer empty */
    }
    USART2->DR = u1_data;
}

/***********************************************************************
 * @fn      - uart_send_string
 * @brief   - Send a null-terminated string one character at a time.
 * @param   - pc_str : pointer to null-terminated string
 * @return  - void
 ************************************************************************/
void uart_send_string(const char *pc_str)
{
    while (*pc_str != '\0')
    {
        uart_send_char((uint8_t)*pc_str);
        pc_str++;
    }
}

/* Private functions ----------------------------------------------------*/
