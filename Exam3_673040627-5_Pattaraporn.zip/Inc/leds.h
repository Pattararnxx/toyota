#ifndef LEDS_H
#define LEDS_H

/* Include ---------------------------------------------------------*/
#include <stdint.h>

/* Public function prototype --------------------------------------*/
void leds_init(void);
void leds_turn_on(void);
void leds_turn_off(void);

#endif /* LEDS_H */
