#ifndef SENSORS_H
#define SENSORS_H

/* Include ---------------------------------------------------------*/
#include <stdint.h>

/* Public function prototype --------------------------------------*/
void sensors_init(void);
int32_t sensors_read_temperature_millidegC(void);
uint16_t sensors_read_light_lux(void);

#endif /* SENSORS_H */
