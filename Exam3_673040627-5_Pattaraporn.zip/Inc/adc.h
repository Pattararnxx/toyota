#ifndef ADC_H
#define ADC_H

/* Include ---------------------------------------------------------*/
#define STM32F411xE
#include "stm32f4xx.h"

/* Public define -----------------------------------------------------*/
#define ADC_MAX_VALUE      (4095u)   /* 12-bit ADC full-scale value */
#define ADC_CH_TEMPERATURE (0u)      /* PA0 = ADC1_IN0 (NTC sensor) */
#define ADC_CH_LIGHT       (1u)      /* PA1 = ADC1_IN1 (LDR sensor) */

/* Public function prototype --------------------------------------*/
void adc_init(void);
uint16_t adc_read_channel(uint8_t u1_channel);

#endif /* ADC_H */
