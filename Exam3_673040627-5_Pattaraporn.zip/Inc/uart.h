#ifndef UART_H
#define UART_H

/* Include ---------------------------------------------------------*/
#define STM32F411xE
#include "stm32f4xx.h"

/* Public function prototype --------------------------------------*/
void uart_init(void);
uint8_t uart_receive_char(void);
void uart_send_char(uint8_t u1_data);
void uart_send_string(const char *pc_str);

#endif /* UART_H */
