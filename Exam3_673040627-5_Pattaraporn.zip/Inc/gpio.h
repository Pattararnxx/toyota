#ifndef GPIO_H
#define GPIO_H

/* Include ---------------------------------------------------------*/
#define STM32F411xE
#include "stm32f4xx.h"

/* Public function prototype --------------------------------------*/
void gpio_set_output(GPIO_TypeDef *px_port, uint8_t u1_pin);
void gpio_set_input_pullup(GPIO_TypeDef *px_port, uint8_t u1_pin);
void gpio_write(GPIO_TypeDef *px_port, uint8_t u1_pin, uint8_t u1_value);

#endif /* GPIO_H */
