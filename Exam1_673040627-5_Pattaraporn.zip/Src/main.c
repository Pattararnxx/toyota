/***********************************************************************
 * File Name    : main.c
 * Description  : Exam1 - 7-Segment Control
 *                Displays a digit 0-9 on the 7-segment shield.
 *                  - PA10 button : increment (wraps 9 -> 0)
 *                  - PB3  button : decrement (wraps 0 -> 9)
 *                  - PB5  button : reset to 0
 *                All button actions are handled by EXTI interrupts so
 *                the digit changes by exactly one step per press, even
 *                if the button is held down.
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#define STM32F411xE
#include "stm32f4xx.h"
#include "sevenseg.h"
#include "counter.h"
#include "exti.h"

/* Private function prototype -----------------------------------------*/
static void system_init(void);

/***********************************************************************
 * @fn      - main
 * @brief   - Program entry point.
 * @param   - void
 * @return  - int : never returns
 ************************************************************************/
int main(void)
{
    system_init();

    while (1)
    {
        /* No action: all work is event-driven inside the EXTI ISRs */
    }
}

/***********************************************************************
 * @fn      - system_init
 * @brief   - Initialise the 7-segment display, the counter value and
 *            the button interrupts.
 * @param   - void
 * @return  - void
 ************************************************************************/
static void system_init(void)
{
    sevenseg_init();
    counter_reset();
    sevenseg_display(counter_get());
    exti_buttons_init();
}
