/***********************************************************************
 * File Name    : sevenseg.c
 * Description  : Drive the 4-bit BCD input lines of the 7-segment shield.
 *                The shield decodes the 4 BCD lines into segments
 *                internally, so this module only needs to output the
 *                binary value of the digit (0-9) on 4 GPIO pins.
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "sevenseg.h"
#include "gpio.h"

/* Private define ----------------------------------------------------*/
#define SEVENSEG_PORT_D0  GPIOC
#define SEVENSEG_PIN_D0   (7u)    /* PC7  -> BCD bit 2^0 */
#define SEVENSEG_PORT_D1  GPIOA
#define SEVENSEG_PIN_D1   (8u)    /* PA8  -> BCD bit 2^1 */
#define SEVENSEG_PORT_D2  GPIOB
#define SEVENSEG_PIN_D2   (10u)   /* PB10 -> BCD bit 2^2 */
#define SEVENSEG_PORT_D3  GPIOA
#define SEVENSEG_PIN_D3   (9u)    /* PA9  -> BCD bit 2^3 */

#define SEVENSEG_BIT0_SHIFT (0u)
#define SEVENSEG_BIT1_SHIFT (1u)
#define SEVENSEG_BIT2_SHIFT (2u)
#define SEVENSEG_BIT3_SHIFT (3u)
#define SEVENSEG_BIT_MASK   (0x01u)

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - sevenseg_init
 * @brief   - Enable clocks for the ports used and configure the 4
 *            BCD pins as push-pull outputs.
 * @param   - void
 * @return  - void
 ************************************************************************/
void sevenseg_init(void)
{
    RCC->AHB1ENR |= (RCC_AHB1ENR_GPIOAEN |
                      RCC_AHB1ENR_GPIOBEN |
                      RCC_AHB1ENR_GPIOCEN);

    gpio_set_output(SEVENSEG_PORT_D0, SEVENSEG_PIN_D0);
    gpio_set_output(SEVENSEG_PORT_D1, SEVENSEG_PIN_D1);
    gpio_set_output(SEVENSEG_PORT_D2, SEVENSEG_PIN_D2);
    gpio_set_output(SEVENSEG_PORT_D3, SEVENSEG_PIN_D3);
}

/***********************************************************************
 * @fn      - sevenseg_display
 * @brief   - Output a 0-9 value on the 4 BCD lines of the shield.
 * @param   - u1_number : digit to display, valid range 0-9
 * @return  - void
 ************************************************************************/
void sevenseg_display(uint8_t u1_number)
{
    if (u1_number <= SEVENSEG_MAX_DIGIT)
    {
        gpio_write(SEVENSEG_PORT_D0, SEVENSEG_PIN_D0,
                   (uint8_t)((u1_number >> SEVENSEG_BIT0_SHIFT) & SEVENSEG_BIT_MASK));
        gpio_write(SEVENSEG_PORT_D1, SEVENSEG_PIN_D1,
                   (uint8_t)((u1_number >> SEVENSEG_BIT1_SHIFT) & SEVENSEG_BIT_MASK));
        gpio_write(SEVENSEG_PORT_D2, SEVENSEG_PIN_D2,
                   (uint8_t)((u1_number >> SEVENSEG_BIT2_SHIFT) & SEVENSEG_BIT_MASK));
        gpio_write(SEVENSEG_PORT_D3, SEVENSEG_PIN_D3,
                   (uint8_t)((u1_number >> SEVENSEG_BIT3_SHIFT) & SEVENSEG_BIT_MASK));
    }
    else
    {
        /* No action: value out of displayable range */
    }
}

/* Private functions ----------------------------------------------------*/
