/***********************************************************************
 * File Name    : exti.c
 * Description  : Configure PA10 (increment), PB3 (decrement) and
 *                PB5 (reset) as falling-edge external interrupts and
 *                update the 7-segment display from within each ISR.
 *                Falling edge only is used (active-low buttons with
 *                internal pull-up) so exactly one interrupt fires per
 *                press, regardless of how long the button is held.
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "exti.h"
#include "gpio.h"
#include "counter.h"
#include "sevenseg.h"

/* Private define ----------------------------------------------------*/
#define BTN_INC_PORT   GPIOA
#define BTN_INC_PIN    (10u)   /* PA10 -> EXTI line 10 */
#define BTN_DEC_PORT   GPIOB
#define BTN_DEC_PIN    (3u)    /* PB3  -> EXTI line 3  */
#define BTN_RST_PORT   GPIOB
#define BTN_RST_PIN    (5u)    /* PB5  -> EXTI line 5  */

#define SYSCFG_PORTCODE_A (0x0u)
#define SYSCFG_PORTCODE_B (0x1u)

#define EXTICR_FIELD_WIDTH (4u)
#define EXTICR_PINS_PER_REG (4u)

/* Private function prototype -----------------------------------------*/
static void exti_route_line(uint8_t u1_pin, uint32_t u4_portCode);
static void exti_configure_line(uint8_t u1_pin);

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - exti_buttons_init
 * @brief   - Enable clocks, configure the 3 button pins as pull-up
 *            inputs, route them to their EXTI line, enable falling
 *            edge detection and enable the associated NVIC interrupts.
 * @param   - void
 * @return  - void
 ************************************************************************/
void exti_buttons_init(void)
{
    RCC->AHB1ENR |= (RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN);
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;

    gpio_set_input_pullup(BTN_INC_PORT, BTN_INC_PIN);
    gpio_set_input_pullup(BTN_DEC_PORT, BTN_DEC_PIN);
    gpio_set_input_pullup(BTN_RST_PORT, BTN_RST_PIN);

    exti_route_line(BTN_INC_PIN, SYSCFG_PORTCODE_A);
    exti_route_line(BTN_DEC_PIN, SYSCFG_PORTCODE_B);
    exti_route_line(BTN_RST_PIN, SYSCFG_PORTCODE_B);

    exti_configure_line(BTN_INC_PIN);
    exti_configure_line(BTN_DEC_PIN);
    exti_configure_line(BTN_RST_PIN);

    NVIC_EnableIRQ(EXTI15_10_IRQn);  /* covers line 10 (PA10) */
    NVIC_EnableIRQ(EXTI3_IRQn);      /* covers line 3  (PB3)  */
    NVIC_EnableIRQ(EXTI9_5_IRQn);    /* covers line 5  (PB5)  */

    NVIC_SetPriority(EXTI15_10_IRQn, 0u);
    NVIC_SetPriority(EXTI3_IRQn, 0u);
    NVIC_SetPriority(EXTI9_5_IRQn, 0u);
}

/***********************************************************************
 * @fn      - EXTI15_10_IRQHandler
 * @brief   - Handles EXTI lines 10-15. Only line 10 (PA10 / increment
 *            button) is used in this program.
 ************************************************************************/
void EXTI15_10_IRQHandler(void)
{
    if ((EXTI->PR & (1u << BTN_INC_PIN)) != 0u)
    {
        EXTI->PR = (1u << BTN_INC_PIN);   /* clear pending: write 1 to clear */
        counter_increment();
        sevenseg_display(counter_get());
    }
    else
    {
        /* No action: interrupt not from the expected line */
    }
}

/***********************************************************************
 * @fn      - EXTI3_IRQHandler
 * @brief   - Handles EXTI line 3 (PB3 / decrement button).
 ************************************************************************/
void EXTI3_IRQHandler(void)
{
    if ((EXTI->PR & (1u << BTN_DEC_PIN)) != 0u)
    {
        EXTI->PR = (1u << BTN_DEC_PIN);
        counter_decrement();
        sevenseg_display(counter_get());
    }
    else
    {
        /* No action: interrupt not from the expected line */
    }
}

/***********************************************************************
 * @fn      - EXTI9_5_IRQHandler
 * @brief   - Handles EXTI lines 5-9. Only line 5 (PB5 / reset button)
 *            is used in this program.
 ************************************************************************/
void EXTI9_5_IRQHandler(void)
{
    if ((EXTI->PR & (1u << BTN_RST_PIN)) != 0u)
    {
        EXTI->PR = (1u << BTN_RST_PIN);
        counter_reset();
        sevenseg_display(counter_get());
    }
    else
    {
        /* No action: interrupt not from the expected line */
    }
}

/* Private functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - exti_route_line
 * @brief   - Select which GPIO port drives the given EXTI line number
 *            through the SYSCFG external interrupt configuration
 *            registers.
 * @param   - u1_pin     : pin / EXTI line number (0-15)
 *           - u4_portCode : port code (0 = A, 1 = B, ...)
 * @return  - void
 ************************************************************************/
static void exti_route_line(uint8_t u1_pin, uint32_t u4_portCode)
{
    uint32_t u4t_regIndex = (uint32_t)u1_pin / EXTICR_PINS_PER_REG;
    uint32_t u4t_fieldPos = ((uint32_t)u1_pin % EXTICR_PINS_PER_REG) * EXTICR_FIELD_WIDTH;

    SYSCFG->EXTICR[u4t_regIndex] &= ~(0xFu << u4t_fieldPos);
    SYSCFG->EXTICR[u4t_regIndex] |= (u4_portCode << u4t_fieldPos);
}

/***********************************************************************
 * @fn      - exti_configure_line
 * @brief   - Unmask the EXTI line and enable falling edge detection.
 * @param   - u1_pin : EXTI line number (0-15)
 * @return  - void
 ************************************************************************/
static void exti_configure_line(uint8_t u1_pin)
{
    EXTI->FTSR |= (1u << u1_pin);
    EXTI->RTSR &= ~(1u << u1_pin);
    EXTI->IMR |= (1u << u1_pin);
}
