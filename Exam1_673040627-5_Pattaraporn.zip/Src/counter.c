/***********************************************************************
 * File Name    : counter.c
 * Description  : Holds the current 7-segment digit value (0-9) and
 *                provides wrap-around increment / decrement / reset.
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "counter.h"

/* Private define ----------------------------------------------------*/
#define COUNTER_MIN_VALUE (0u)
#define COUNTER_MAX_VALUE (9u)
#define COUNTER_WRAP_MOD  (10u)

/* Private variables ---------------------------------------------------*/
static uint8_t u1s_currentValue = 0u;

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - counter_reset
 * @brief   - Reset the counter value to 0.
 * @param   - void
 * @return  - void
 ************************************************************************/
void counter_reset(void)
{
    u1s_currentValue = COUNTER_MIN_VALUE;
}

/***********************************************************************
 * @fn      - counter_increment
 * @brief   - Increase the counter by 1, wrapping from 9 back to 0.
 * @param   - void
 * @return  - void
 ************************************************************************/
void counter_increment(void)
{
    u1s_currentValue = (uint8_t)((u1s_currentValue + 1u) % COUNTER_WRAP_MOD);
}

/***********************************************************************
 * @fn      - counter_decrement
 * @brief   - Decrease the counter by 1, wrapping from 0 back to 9.
 * @param   - void
 * @return  - void
 ************************************************************************/
void counter_decrement(void)
{
    if (u1s_currentValue == COUNTER_MIN_VALUE)
    {
        u1s_currentValue = COUNTER_MAX_VALUE;
    }
    else
    {
        u1s_currentValue = (uint8_t)(u1s_currentValue - 1u);
    }
}

/***********************************************************************
 * @fn      - counter_get
 * @brief   - Get the current counter value.
 * @param   - void
 * @return  - uint8_t : current value, range 0-9
 ************************************************************************/
uint8_t counter_get(void)
{
    return u1s_currentValue;
}

/* Private functions ----------------------------------------------------*/
