#ifndef EXTI_H
#define EXTI_H

/* Include ---------------------------------------------------------*/
#define STM32F411xE
#include "stm32f4xx.h"

/* Public function prototype --------------------------------------*/
void exti_buttons_init(void);

#endif /* EXTI_H */
