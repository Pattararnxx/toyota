#ifndef COUNTER_H
#define COUNTER_H

/* Include ---------------------------------------------------------*/
#include <stdint.h>

/* Public function prototype --------------------------------------*/
void counter_reset(void);
void counter_increment(void);
void counter_decrement(void);
uint8_t counter_get(void);

#endif /* COUNTER_H */
