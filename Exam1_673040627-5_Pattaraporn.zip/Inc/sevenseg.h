#ifndef SEVENSEG_H
#define SEVENSEG_H

/* Include ---------------------------------------------------------*/
#define STM32F411xE
#include "stm32f4xx.h"

/* Public define -----------------------------------------------------*/
#define SEVENSEG_MIN_DIGIT (0u)
#define SEVENSEG_MAX_DIGIT (9u)

/* Public function prototype --------------------------------------*/
void sevenseg_init(void);
void sevenseg_display(uint8_t u1_number);

#endif /* SEVENSEG_H */
