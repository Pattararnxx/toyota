/***********************************************************************
 * File Name    : ledbar.c
 * Description  : Drives a row of 4 LEDs from the potentiometer ADC
 *                reading.
 *                  - Fully clockwise  (ADC = ADC_MAX_VALUE) -> 0 LEDs on
 *                  - Fully counter-clockwise (ADC = 0)      -> all LEDs on
 *                Rotating the pot counter-clockwise lowers the ADC
 *                value, which lights up LEDs one by one in order.
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "ledbar.h"
#include "gpio.h"
#include "adc.h"

/* Private define ----------------------------------------------------*/
#define LEDBAR_STEP_SIZE ((ADC_MAX_VALUE + 1u) / LEDBAR_NUM_LEDS)

/* Private variables ---------------------------------------------------*/
static GPIO_TypeDef * const gpx_ledPort[LEDBAR_NUM_LEDS] = { GPIOB, GPIOA, GPIOA, GPIOA };
static const uint8_t gu1_ledPin[LEDBAR_NUM_LEDS] = { 6u, 7u, 6u, 5u }; /* PB6, PA7, PA6, PA5 */

/* Private function prototype -----------------------------------------*/
static uint8_t ledbar_calc_level(uint16_t u2_adcValue);

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - ledbar_init
 * @brief   - Enable clocks and configure all 4 LED pins as outputs,
 *            starting in the OFF state.
 * @param   - void
 * @return  - void
 ************************************************************************/
void ledbar_init(void)
{
    uint8_t u1t_index;

    RCC->AHB1ENR |= (RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN);

    for (u1t_index = 0u; u1t_index < LEDBAR_NUM_LEDS; u1t_index++)
    {
        gpio_set_output(gpx_ledPort[u1t_index], gu1_ledPin[u1t_index]);
        gpio_write(gpx_ledPort[u1t_index], gu1_ledPin[u1t_index], 0u);
    }
}

/***********************************************************************
 * @fn      - ledbar_update
 * @brief   - Convert the given ADC reading into a LED level (0-4) and
 *            drive the LEDs so that the first N LEDs are ON and the
 *            remaining ones are OFF.
 * @param   - u2_adcValue : raw 12-bit ADC reading, range 0-4095
 * @return  - void
 ************************************************************************/
void ledbar_update(uint16_t u2_adcValue)
{
    uint8_t u1t_level = ledbar_calc_level(u2_adcValue);
    uint8_t u1t_index;

    for (u1t_index = 0u; u1t_index < LEDBAR_NUM_LEDS; u1t_index++)
    {
        if (u1t_index < u1t_level)
        {
            gpio_write(gpx_ledPort[u1t_index], gu1_ledPin[u1t_index], 1u);
        }
        else
        {
            gpio_write(gpx_ledPort[u1t_index], gu1_ledPin[u1t_index], 0u);
        }
    }
}

/* Private functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - ledbar_calc_level
 * @brief   - Map an ADC reading to a LED level between 0 and
 *            LEDBAR_NUM_LEDS. High ADC value (pot fully clockwise) maps
 *            to level 0 (all LEDs off); low ADC value (pot fully
 *            counter-clockwise) maps to level LEDBAR_NUM_LEDS
 *            (all LEDs on).
 * @param   - u2_adcValue : raw 12-bit ADC reading, range 0-4095
 * @return  - uint8_t : LED level, range 0-LEDBAR_NUM_LEDS
 ************************************************************************/
static uint8_t ledbar_calc_level(uint16_t u2_adcValue)
{
    uint16_t u2t_stepsFromTop = (uint16_t)((ADC_MAX_VALUE - u2_adcValue) / LEDBAR_STEP_SIZE);
    uint8_t u1t_level;

    if (u2t_stepsFromTop > LEDBAR_NUM_LEDS)
    {
        u1t_level = LEDBAR_NUM_LEDS;
    }
    else
    {
        u1t_level = (uint8_t)u2t_stepsFromTop;
    }

    return u1t_level;
}
