/***********************************************************************
 * File Name    : adc.c
 * Description  : Single-channel ADC1 polling driver used to read the
 *                potentiometer on PA0 (ADC1_IN0).
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "adc.h"

/* Private define ----------------------------------------------------*/
#define ADC_POT_CHANNEL      (0u)   /* PA0 = ADC1_IN0 */
#define ADC_POT_GPIO_PIN     (0u)
#define ADC_SAMPLE_TIME_LONG (0x7u)
#define ADC_MODER_BITS_PER_PIN (2u)
#define ADC_MODE_ANALOG      (0x3u)
#define ADC_SMPR2_BITS_PER_CH (3u)
#define ADC_SQR1_SINGLE_CONV  (0u)

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - adc_init
 * @brief   - Enable clocks, configure PA0 as analog input and
 *            configure ADC1 for a single-conversion regular sequence
 *            on channel 0.
 * @param   - void
 * @return  - void
 ************************************************************************/
void adc_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

    GPIOA->MODER |= (ADC_MODE_ANALOG << (ADC_POT_GPIO_PIN * ADC_MODER_BITS_PER_PIN));

    ADC1->CR2 &= ~ADC_CR2_CONT;
    ADC1->SMPR2 |= (ADC_SAMPLE_TIME_LONG << (ADC_POT_CHANNEL * ADC_SMPR2_BITS_PER_CH));
    ADC1->SQR1 &= ~ADC_SQR1_L;
    ADC1->SQR1 |= (ADC_SQR1_SINGLE_CONV << ADC_SQR1_L_Pos);
    ADC1->SQR3 &= ~ADC_SQR3_SQ1;
    ADC1->SQR3 |= (ADC_POT_CHANNEL << ADC_SQR3_SQ1_Pos);

    ADC1->CR2 |= ADC_CR2_ADON;
}

/***********************************************************************
 * @fn      - adc_read
 * @brief   - Start a conversion, wait for completion and return the
 *            12-bit result.
 * @param   - void
 * @return  - uint16_t : conversion result, range 0-4095
 ************************************************************************/
uint16_t adc_read(void)
{
    ADC1->CR2 |= ADC_CR2_SWSTART;
    while ((ADC1->SR & ADC_SR_EOC) == 0u)
    {
        /* wait until conversion is complete */
    }
    return (uint16_t)ADC1->DR;
}

/* Private functions ----------------------------------------------------*/
