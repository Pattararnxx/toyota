/***********************************************************************
 * File Name    : main.c
 * Description  : Exam2 - Potentiometer-controlled LED bar
 *                  - Pot fully clockwise        -> all LEDs OFF
 *                  - Rotating pot counter-clockwise -> LEDs turn on
 *                    one by one as the ADC reading decreases
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#define STM32F411xE
#include "stm32f4xx.h"
#include "adc.h"
#include "ledbar.h"

/* Private define ----------------------------------------------------*/
#define LOOP_DELAY_COUNT (100000u)

/* Private function prototype -----------------------------------------*/
static void system_init(void);
static void delay(uint32_t u4_count);

/***********************************************************************
 * @fn      - main
 * @brief   - Program entry point. Continuously reads the potentiometer
 *            and updates the LED bar accordingly.
 * @param   - void
 * @return  - int : never returns
 ************************************************************************/
int main(void)
{
    uint16_t u2t_adcValue;

    system_init();

    while (1)
    {
        u2t_adcValue = adc_read();
        ledbar_update(u2t_adcValue);
        delay(LOOP_DELAY_COUNT);
    }
}

/***********************************************************************
 * @fn      - system_init
 * @brief   - Initialise the ADC and the LED bar.
 * @param   - void
 * @return  - void
 ************************************************************************/
static void system_init(void)
{
    adc_init();
    ledbar_init();
}

/***********************************************************************
 * @fn      - delay
 * @brief   - Simple blocking busy-wait delay.
 * @param   - u4_count : number of empty loop iterations
 * @return  - void
 ************************************************************************/
static void delay(uint32_t u4_count)
{
    volatile uint32_t u4t_i;

    for (u4t_i = 0u; u4t_i < u4_count; u4t_i++)
    {
        /* No action: busy wait */
    }
}
