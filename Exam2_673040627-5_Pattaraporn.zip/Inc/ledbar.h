#ifndef LEDBAR_H
#define LEDBAR_H

/* Include ---------------------------------------------------------*/
#include <stdint.h>

/* Public define -----------------------------------------------------*/
#define LEDBAR_NUM_LEDS (4u)

/* Public function prototype --------------------------------------*/
void ledbar_init(void);
void ledbar_update(uint16_t u2_adcValue);

#endif /* LEDBAR_H */
