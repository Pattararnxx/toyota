#ifndef ADC_H
#define ADC_H

/* Include ---------------------------------------------------------*/
#define STM32F411xE
#include "stm32f4xx.h"

/* Public define -----------------------------------------------------*/
#define ADC_MAX_VALUE (4095u)   /* 12-bit ADC full-scale value */

/* Public function prototype --------------------------------------*/
void adc_init(void);
uint16_t adc_read(void);

#endif /* ADC_H */
