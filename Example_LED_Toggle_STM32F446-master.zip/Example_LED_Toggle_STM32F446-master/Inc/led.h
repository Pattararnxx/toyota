/***********************************************************************
 * File Name	: led.h
 * Description  : Header file for led.c
 *                LED module for the LED-toggle project. Wraps the GPIO
 *                driver so the application controls the LED by name.
 ************************************************************************
 */

#ifndef LED_H
#define LED_H

/* Include -------------------------------------------------------------*/

/* Private includes -----------------------------------------------------*/

/* Private typedef ------------------------------------------------------*/

/* Private define -------------------------------------------------------*/
/* LED: PC1, active-high */
#define LED_PORT              GPIOC                 /* GPIO port for the LED       */
#define LED_PIN               (1U)                  /* Pin number within the port  */
#define LED_PORT_CLK_EN       RCC_AHB1ENR_GPIOCEN   /* Clock-enable bit for PORTC  */
#define LED_LEVEL_ON          (1U)                  /* Pin level that light LED   */
#define LED_LEVEL_OFF         (0U)                  /* Pin level that darkens LED  */

/* Private macro --------------------------------------------------------*/

/* Public function prototype --------------------------------------------*/

/***********************************************************************
 * @fn				- led_init
 * @brief			- Configure the LED pin as an output and start it OFF.
 *
 * @param[in]		- void
 *
 * @return			- void
 *
 * @Note			- The LED port clock must already be enabled.
 *////////////////////////////////////////////////////////////////////////////////////
void led_init(void);

/***********************************************************************
 * @fn				- led_set_toggle
 * @brief			- Invert the LED (on -> off, off -> on).
 *
 * @param[in]		- void
 *
 * @return			- void
 *
 * @Note			- none
 *////////////////////////////////////////////////////////////////////////////////////
void led_set_toggle(void);

#endif /* LED_H */
