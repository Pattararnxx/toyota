/***********************************************************************
 * File Name	: exti.h
 * Description  : Header file for exti.c
 *                Configures PB10 as an external interrupt (EXTI) source.
 *                The interrupt is serviced by EXTI15_10_IRQHandler in
 *                main.c, which toggles the LED.
 ************************************************************************
 */

#ifndef EXTI_H
#define EXTI_H

/* Include -------------------------------------------------------------*/
#include "stm32f446xx.h"   /* CMSIS: SYSCFG, EXTI, NVIC, IRQn_Type */

/* Private includes -----------------------------------------------------*/

/* Private typedef ------------------------------------------------------*/

/* Private define -------------------------------------------------------*/
#define EXTI_PB10_LINE          (10U)  /* PB10 -> EXTI line 10                    */

/* Private macro --------------------------------------------------------*/
/* Bit mask for a single EXTI/GPIO line (0..15). */
#define EXTI_LINE_MASK(line)    ((uint32_t)1U << (line))

/* Public function prototype --------------------------------------------*/

/***********************************************************************
 * @fn				- exti_init
 * @brief			- Route PB10 to EXTI line 10, trigger on the falling
 *                    edge, unmask the line, and enable its NVIC interrupt.
 *
 * @param[in]		- void
 *
 * @return			- void
 *
 * @Note			- PB10 must already be an input and the SYSCFG clock
 *                    (RCC APB2) must be enabled. The interrupt is serviced
 *                    by EXTI15_10_IRQHandler in main.c.
 *////////////////////////////////////////////////////////////////////////////////////
void exti_init(void);

#endif /* EXTI_H */
