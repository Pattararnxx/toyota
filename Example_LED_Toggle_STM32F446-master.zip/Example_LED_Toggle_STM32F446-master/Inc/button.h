/***********************************************************************
 * File Name	: button.h
 * Description  : Header file for button.c
 *                Button pin configuration (input + pull resistor). The press
 *                itself is handled by the EXTI interrupt, not polled here.
 ************************************************************************
 */

#ifndef BUTTON_H
#define BUTTON_H

/* Include -------------------------------------------------------------*/
#include <stdint.h>

/* Private includes -----------------------------------------------------*/

/* Private typedef ------------------------------------------------------*/

/* Private define -------------------------------------------------------*/
/* Button: PB10, active-low with internal pull-up */
#define BUTTON_PORT           GPIOB                 /* GPIO port for the button    */
#define BUTTON_PIN            (10U)                 /* Pin number within the port  */
#define BUTTON_PORT_CLK_EN    RCC_AHB1ENR_GPIOBEN   /* Clock-enable bit for PORTB  */
#define BUTTON_PULL_UP        GPIO_PULL_UP          /* Internal pull-up (idle HIGH)*/
#define BUTTON_LEVEL_PRESSED  (0U)                  /* Pin level while pressed     */

/* Private macro --------------------------------------------------------*/

/* Public function prototype --------------------------------------------*/

/***********************************************************************
 * @fn				- button_init
 * @brief			- Configure the button pin as an input
 *                    (input mode + pull resistor from board_config.h).
 *
 * @param[in]		- void
 *
 * @return			- void
 *
 * @Note			- The button port clock must already be enabled.
 *////////////////////////////////////////////////////////////////////////////////////
void button_init(void);

#endif /* BUTTON_H */
