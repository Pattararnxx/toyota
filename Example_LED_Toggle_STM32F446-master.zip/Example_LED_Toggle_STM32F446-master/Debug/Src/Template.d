Src/Template.o: ../Src/Template.c
