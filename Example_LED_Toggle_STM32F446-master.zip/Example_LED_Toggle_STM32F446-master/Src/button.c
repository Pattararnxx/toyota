/***********************************************************************
 * File Name	: button.c
 * Description  : Button pin configuration (input + pull resistor).
 ************************************************************************
 */

/* Include -------------------------------------------------------------*/
#include "button.h"

/* Private includes -----------------------------------------------------*/
#include "gpio.h"

/* Private typedef ------------------------------------------------------*/

/* Private define -------------------------------------------------------*/

/* Private macro --------------------------------------------------------*/

/* Private variables ----------------------------------------------------*/

/* Private function prototype -------------------------------------------*/

/* Public functions -----------------------------------------------------*/

/***********************************************************************
 * @fn				- button_init
 * @brief			- Configure the button pin as an input
 *                    (input mode + pull resistor from board_config.h).
 *
 * @param[in]		- void
 *
 * @return			- void
 *
 * @Note			- The button port clock must already be enabled.
 *////////////////////////////////////////////////////////////////////////////////////
void button_init(void)
{
    gpio_set_mode(BUTTON_PORT, BUTTON_PIN, GPIO_MODE_INPUT);
    gpio_set_pull(BUTTON_PORT, BUTTON_PIN, BUTTON_PULL_UP);
}

/* Callback functions ---------------------------------------------------*/

/* Private functions ----------------------------------------------------*/
