/***********************************************************************
 * File Name	: exti.c
 * Description  : Implementation of the PB10 external-interrupt (EXTI)
 *                module. Hardwired to EXTI line 10 (EXTI15_10 group). The
 *                interrupt itself is serviced by EXTI15_10_IRQHandler in
 *                main.c.
 ************************************************************************
 */

/* Include -------------------------------------------------------------*/
#include "exti.h"

/* Private includes -----------------------------------------------------*/

/* Private typedef ------------------------------------------------------*/

/* Private define -------------------------------------------------------*/
#define EXTI_PB10_PORT_CODE     (1U)   /* SYSCFG port code for GPIOB              */
#define EXTI_PB10_EXTICR_REG    (2U)   /* SYSCFG->EXTICR[2] covers lines 8..11    */
#define EXTI_PB10_EXTICR_SHIFT  (8U)   /* line 10 -> bits [11:8] within EXTICR[2] */
#define EXTICR_FIELD_MASK       (0xFU) /* Mask for one line's 4-bit field         */

/* Private macro --------------------------------------------------------*/

/* Private variables ----------------------------------------------------*/

/* Private function prototype -------------------------------------------*/

/* Public functions -----------------------------------------------------*/

/***********************************************************************
 * @fn				- exti_init
 * @brief			- Route PB10 to EXTI line 10, trigger on the falling
 *                    edge, unmask the line, and enable its NVIC interrupt.
 *
 * @param[in]		- void
 *
 * @return			- void
 *
 * @Note			- PB10 must be an input; SYSCFG clock must be enabled.
 *                    The NVIC line is fixed to the EXTI15_10 group.
 *////////////////////////////////////////////////////////////////////////////////////
void exti_init(void)
{
    /* 1. Route PB10's port (GPIOB) to EXTI line 10 (SYSCFG multiplexer). */
    SYSCFG->EXTICR[EXTI_PB10_EXTICR_REG] &= ~(EXTICR_FIELD_MASK << EXTI_PB10_EXTICR_SHIFT);
    SYSCFG->EXTICR[EXTI_PB10_EXTICR_REG] |= (EXTI_PB10_PORT_CODE << EXTI_PB10_EXTICR_SHIFT);

    /* 2. Trigger on the falling edge (active-low button press). */
    EXTI->FTSR |= EXTI_LINE_MASK(EXTI_PB10_LINE);

    /* 3. Unmask (enable) the EXTI line. */
    EXTI->IMR |= EXTI_LINE_MASK(EXTI_PB10_LINE);

    /* 4. Enable the interrupt in the NVIC (line 10 -> EXTI15_10 group). */
    NVIC_EnableIRQ(EXTI15_10_IRQn);
}

/* Callback functions ---------------------------------------------------*/

/* Private functions ----------------------------------------------------*/
