/***********************************************************************
 * File Name	: led.c
 * Description  : Implementation of the LED module.
 ************************************************************************
 */

/* Include -------------------------------------------------------------*/
#include "led.h"

/* Private includes -----------------------------------------------------*/
#include "gpio.h"

/* Private typedef ------------------------------------------------------*/

/* Private define -------------------------------------------------------*/

/* Private macro --------------------------------------------------------*/

/* Private variables ----------------------------------------------------*/

/* Private function prototype -------------------------------------------*/

/* Public functions -----------------------------------------------------*/

/***********************************************************************
 * @fn				- led_init
 * @brief			- Configure the LED pin as an output and start it OFF.
 *
 * @param[in]		- void
 *
 * @return			- void
 *
 * @Note			- The LED port clock must already be enabled.
 *////////////////////////////////////////////////////////////////////////////////////
void led_init(void)
{
    gpio_set_mode(LED_PORT, LED_PIN, GPIO_MODE_OUTPUT);
    gpio_write(LED_PORT, LED_PIN, LED_LEVEL_OFF);
}

/***********************************************************************
 * @fn				- led_set_toggle
 * @brief			- Invert the LED (on -> off, off -> on).
 *
 * @param[in]		- void
 *
 * @return			- void
 *
 * @Note			- none
 *////////////////////////////////////////////////////////////////////////////////////
void led_set_toggle(void)
{
    gpio_toggle(LED_PORT, LED_PIN);
}

/* Callback functions ---------------------------------------------------*/

/* Private functions ----------------------------------------------------*/
