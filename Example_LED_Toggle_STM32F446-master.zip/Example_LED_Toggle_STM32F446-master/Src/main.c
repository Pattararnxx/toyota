/***********************************************************************
 * File Name	: main.c
 * Description  : Bare-metal 1-button / 1-LED toggle application.
 *                A press of the button (PB10) triggers an EXTI interrupt
 *                whose handler toggles the LED (PC1). The main loop does
 *                nothing; all the work happens in the interrupt.
 ************************************************************************
 */

/* Include -------------------------------------------------------------*/
#include "stm32f446xx.h"   /* CMSIS: RCC handle, RCC_APB2ENR_SYSCFGEN */

/* Private includes -----------------------------------------------------*/
#include "led.h"
#include "button.h"
#include "exti.h"

/* Private typedef ------------------------------------------------------*/

/* Private define -------------------------------------------------------*/

/* Private macro --------------------------------------------------------*/

/* Private variables ----------------------------------------------------*/

/* Private function prototype -------------------------------------------*/
static void board_init(void);
static void rcc_clock_enable(void);
void EXTI15_10_IRQHandler(void);   /* Strong override of the startup weak symbol */

/* Public functions -----------------------------------------------------*/

/***********************************************************************
 * @fn				- main
 * @brief			- Program entry point. Sets up the board, then idles
 *                    while the EXTI interrupt handles button presses.
 *
 * @param[in]		- void
 *
 * @return			- int : standard C signature only; the super-loop never
 *                    exits, so control never reaches a return.
 *
 * @Note			- The LED is toggled from on_button_press(), not here.
 *////////////////////////////////////////////////////////////////////////////////////

/* Main function -------------------------------------------------------------*/
int main(void)
{
    board_init();

    while (1)
    {
        /* Nothing to do: button presses are serviced by the EXTI interrupt. */
    }
}

/* Callback functions ---------------------------------------------------*/

/***********************************************************************
 * @fn				- EXTI15_10_IRQHandler
 * @brief			- Interrupt handler for EXTI lines 10..15. Clears the
 *                    button's pending flag and toggles the LED.
 *
 * @param[in]		- void  (called by the NVIC via the vector table)
 *
 * @return			- void
 *
 * @Note			- Name must match the startup vector table exactly.
 *                    Runs in interrupt context, so it stays short.
 *////////////////////////////////////////////////////////////////////////////////////
void EXTI15_10_IRQHandler(void)
{
    uint32_t pb10_mask = EXTI_LINE_MASK(EXTI_PB10_LINE);   /* Pending-bit mask for PB10 */

    /* Did PB10 (EXTI line 10) trigger the interrupt? */
    if ((EXTI->PR & pb10_mask) == pb10_mask)
    {
        EXTI->PR = pb10_mask;   /* Clear pending: write 1 to the bit */
        led_set_toggle();
    }
    else
    {
    	/* Do nothing */
    }
}

/* Private functions ----------------------------------------------------*/

/***********************************************************************
 * @fn				- board_init
 * @brief			- Enable clocks, configure the LED and button pins, and
 *                    wire the button up as an EXTI interrupt source.
 *
 * @param[in]		- void
 *
 * @return			- void
 *
 * @Note			- Clocks are enabled first; pin config depends on them.
 *////////////////////////////////////////////////////////////////////////////////////
static void board_init(void)
{
    rcc_clock_enable();

    led_init();
    button_init();

    /* Arm the button's EXTI interrupt (serviced by EXTI15_10_IRQHandler). */
    exti_init();
}

/***********************************************************************
 * @fn				- rcc_clock_enable
 * @brief			- Enable the peripheral clocks used by the project:
 *                    the GPIO ports (LED + button) and SYSCFG (for EXTI).
 *
 * @param[in]		- void
 *
 * @return			- void
 *
 * @Note			- SYSCFG is on APB2 and is required to route a pin to EXTI.
 *////////////////////////////////////////////////////////////////////////////////////
static void rcc_clock_enable(void)
{
    RCC->AHB1ENR |= (LED_PORT_CLK_EN | BUTTON_PORT_CLK_EN);   /* GPIO ports        */
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;                     /* SYSCFG for EXTI mux */
}
