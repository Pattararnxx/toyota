#ifndef BRIGHTNESS_H
#define BRIGHTNESS_H

/* Include ---------------------------------------------------------*/
#include <stdint.h>

/* Public function prototype --------------------------------------*/
void brightness_update_from_adc(uint16_t u2_adcValue);

#endif /* BRIGHTNESS_H */
