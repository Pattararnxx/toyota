#ifndef PWM_H
#define PWM_H

/* Include ---------------------------------------------------------*/
#include <stdint.h>

/* Public define -----------------------------------------------------*/
#define PWM_DUTY_MIN_PERCENT (0u)
#define PWM_DUTY_MAX_PERCENT (100u)

/* Public function prototype --------------------------------------*/
void pwm_init(void);
void pwm_set_duty_percent(uint8_t u1_percent);

#endif /* PWM_H */
