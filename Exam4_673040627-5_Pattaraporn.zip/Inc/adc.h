#ifndef ADC_H
#define ADC_H

/* Include ---------------------------------------------------------*/
#include <stdint.h>

/* Public define -----------------------------------------------------*/
#define ADC_MAX_VALUE (4095u)   /* 12-bit ADC full-scale value */

/* Public function prototype --------------------------------------*/
void adc_init(void);
void adc_start_conversion(void);

#endif /* ADC_H */
