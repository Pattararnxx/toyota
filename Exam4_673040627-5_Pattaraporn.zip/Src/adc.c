/***********************************************************************
 * File Name    : adc.c
 * Description  : Reads the potentiometer (PA0 / ADC1_IN0) using the
 *                ADC end-of-conversion (EOC) interrupt instead of
 *                polling. main() only has to call
 *                adc_start_conversion() periodically; the result is
 *                collected and applied to the LEDs inside the ISR.
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "adc.h"
#include "brightness.h"
#define STM32F411xE
#include "stm32f4xx.h"

/* Private define ----------------------------------------------------*/
#define ADC_POT_CHANNEL       (0u)   /* PA0 = ADC1_IN0 */
#define ADC_POT_GPIO_PIN      (0u)
#define ADC_MODER_BITS_PER_PIN (2u)
#define ADC_MODE_ANALOG       (0x3u)
#define ADC_SAMPLE_TIME_LONG  (0x7u)
#define ADC_SMPR2_BITS_PER_CH (3u)
#define ADC_SQR1_SINGLE_CONV  (0u)
#define ADC_IRQ_PRIORITY      (0u)

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - adc_init
 * @brief   - Enable clocks, configure PA0 as analog input, configure
 *            ADC1 for single-conversion mode on channel 0 and enable
 *            the end-of-conversion (EOC) interrupt.
 * @param   - void
 * @return  - void
 ************************************************************************/
void adc_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

    GPIOA->MODER |= (ADC_MODE_ANALOG << (ADC_POT_GPIO_PIN * ADC_MODER_BITS_PER_PIN));

    ADC1->CR2 &= ~ADC_CR2_CONT;
    ADC1->SMPR2 |= (ADC_SAMPLE_TIME_LONG << (ADC_POT_CHANNEL * ADC_SMPR2_BITS_PER_CH));
    ADC1->SQR1 &= ~ADC_SQR1_L;
    ADC1->SQR1 |= (ADC_SQR1_SINGLE_CONV << ADC_SQR1_L_Pos);
    ADC1->SQR3 &= ~ADC_SQR3_SQ1;
    ADC1->SQR3 |= (ADC_POT_CHANNEL << ADC_SQR3_SQ1_Pos);

    ADC1->CR1 |= ADC_CR1_EOCIE;   /* enable end-of-conversion interrupt */
    ADC1->CR2 |= ADC_CR2_ADON;

    NVIC_EnableIRQ(ADC_IRQn);
    NVIC_SetPriority(ADC_IRQn, ADC_IRQ_PRIORITY);
}

/***********************************************************************
 * @fn      - adc_start_conversion
 * @brief   - Trigger a new ADC conversion. The result is collected in
 *            ADC_IRQHandler once the conversion completes.
 * @param   - void
 * @return  - void
 ************************************************************************/
void adc_start_conversion(void)
{
    ADC1->CR2 |= ADC_CR2_SWSTART;
}

/***********************************************************************
 * @fn      - ADC_IRQHandler
 * @brief   - Fires when the ADC1 conversion completes (EOC). Reads the
 *            result and updates the LED brightness accordingly.
 ************************************************************************/
void ADC_IRQHandler(void)
{
    if ((ADC1->SR & ADC_SR_EOC) != 0u)
    {
        uint16_t u2t_adcValue = (uint16_t)ADC1->DR;   /* reading DR also clears EOC */

        brightness_update_from_adc(u2t_adcValue);
    }
    else
    {
        /* No action: interrupt not from EOC */
    }
}

/* Private functions ----------------------------------------------------*/
