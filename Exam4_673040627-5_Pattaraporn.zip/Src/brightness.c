/***********************************************************************
 * File Name    : brightness.c
 * Description  : Maps the potentiometer ADC reading to LED brightness.
 *                  - Fully counter-clockwise (ADC = 0)    -> 0% duty (off)
 *                  - Fully clockwise (ADC = ADC_MAX_VALUE) -> 100% duty
 *                Rotating the pot clockwise raises the ADC value, which
 *                gradually increases the LED brightness.
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "brightness.h"
#include "adc.h"
#include "pwm.h"

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - brightness_update_from_adc
 * @brief   - Convert a raw ADC reading (0-4095) into a duty cycle
 *            (0-100%) and apply it to the LEDs.
 * @param   - u2_adcValue : raw 12-bit ADC reading, range 0-4095
 * @return  - void
 ************************************************************************/
void brightness_update_from_adc(uint16_t u2_adcValue)
{
    uint8_t u1t_dutyPercent = (uint8_t)(((uint32_t)u2_adcValue * PWM_DUTY_MAX_PERCENT) /
                                         ADC_MAX_VALUE);

    pwm_set_duty_percent(u1t_dutyPercent);
}

/* Private functions ----------------------------------------------------*/
