/***********************************************************************
 * File Name    : main.c
 * Description  : Exam4 - Potentiometer-controlled LED brightness
 *                  - Pot fully counter-clockwise -> LEDs off (0% duty)
 *                  - Rotating pot clockwise      -> LEDs brighten
 *                    gradually as the ADC reading increases
 *                  - ADC result is obtained through the EOC interrupt,
 *                    not by polling
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#define STM32F411xE
#include "stm32f4xx.h"
#include "adc.h"
#include "pwm.h"

/* Private define ----------------------------------------------------*/
#define LOOP_DELAY_COUNT (100000u)

/* Private function prototype -----------------------------------------*/
static void system_init(void);
static void delay(uint32_t u4_count);

/***********************************************************************
 * @fn      - main
 * @brief   - Program entry point. Periodically triggers an ADC
 *            conversion; the ADC EOC interrupt reads the result and
 *            updates the LED brightness.
 * @param   - void
 * @return  - int : never returns
 ************************************************************************/
int main(void)
{
    system_init();

    while (1)
    {
        adc_start_conversion();
        delay(LOOP_DELAY_COUNT);
    }
}

/***********************************************************************
 * @fn      - system_init
 * @brief   - Initialise the PWM outputs and the ADC (with EOC
 *            interrupt enabled).
 * @param   - void
 * @return  - void
 ************************************************************************/
static void system_init(void)
{
    pwm_init();
    adc_init();
}

/***********************************************************************
 * @fn      - delay
 * @brief   - Simple blocking busy-wait delay between ADC triggers.
 * @param   - u4_count : number of empty loop iterations
 * @return  - void
 ************************************************************************/
static void delay(uint32_t u4_count)
{
    volatile uint32_t u4t_i;

    for (u4t_i = 0u; u4t_i < u4_count; u4t_i++)
    {
        /* No action: busy wait */
    }
}
