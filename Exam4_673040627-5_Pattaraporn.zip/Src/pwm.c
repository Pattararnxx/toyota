/***********************************************************************
 * File Name    : pwm.c
 * Description  : Generates a 1 kHz PWM signal on TIM3 channels 1, 2
 *                and 3 to control the brightness of the Blue, Red and
 *                Yellow LEDs. All three channels always share the same
 *                duty cycle, so the three LEDs dim/brighten together.
 ************************************************************************/

/* Include ---------------------------------------------------------*/
#include "pwm.h"
#define STM32F411xE
#include "stm32f4xx.h"

/* Private define ----------------------------------------------------*/
#define PWM_LED_BLUE_PIN    (6u)   /* PA6 -> TIM3_CH1 (AF2) */
#define PWM_LED_RED_PIN     (7u)   /* PA7 -> TIM3_CH2 (AF2) */
#define PWM_LED_YELLOW_PIN  (0u)   /* PB0 -> TIM3_CH3 (AF2) */

#define PWM_AF_TIM3          (0x2u)
#define PWM_MODER_BITS_PER_PIN (2u)
#define PWM_MODE_ALT_FUNC     (0x2u)
#define PWM_AFR_BITS_PER_PIN  (4u)

#define PWM_ARR_VALUE (999u)   /* 1000 steps -> fine brightness resolution */
#define PWM_PSC_VALUE (15u)    /* 16MHz / (15+1) = 1MHz timer clock -> 1kHz PWM */
#define PWM_MODE_PWM1 (0x6u)

#define PWM_CCMR1_OC1M_SHIFT (4u)
#define PWM_CCMR1_OC1PE_BIT  (3u)
#define PWM_CCMR1_OC2M_SHIFT (12u)
#define PWM_CCMR1_OC2PE_BIT  (11u)
#define PWM_CCMR2_OC3M_SHIFT (4u)
#define PWM_CCMR2_OC3PE_BIT  (3u)

/* Private function prototype -----------------------------------------*/
static void pwm_configure_gpio(GPIO_TypeDef *px_port, uint8_t u1_pin);

/* Public functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - pwm_init
 * @brief   - Configure PA6, PA7, PB0 as TIM3 alternate function pins
 *            and configure TIM3 channels 1-3 for PWM mode 1, starting
 *            at 0% duty cycle (LEDs off).
 * @param   - void
 * @return  - void
 ************************************************************************/
void pwm_init(void)
{
    RCC->AHB1ENR |= (RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN);
    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;

    pwm_configure_gpio(GPIOA, PWM_LED_BLUE_PIN);
    pwm_configure_gpio(GPIOA, PWM_LED_RED_PIN);
    pwm_configure_gpio(GPIOB, PWM_LED_YELLOW_PIN);

    TIM3->PSC = PWM_PSC_VALUE;
    TIM3->ARR = PWM_ARR_VALUE;
    TIM3->CCR1 = 0u;
    TIM3->CCR2 = 0u;
    TIM3->CCR3 = 0u;

    TIM3->CCMR1 &= ~(TIM_CCMR1_OC1M | TIM_CCMR1_OC2M);
    TIM3->CCMR1 |= (PWM_MODE_PWM1 << PWM_CCMR1_OC1M_SHIFT);
    TIM3->CCMR1 |= (PWM_MODE_PWM1 << PWM_CCMR1_OC2M_SHIFT);
    TIM3->CCMR1 |= (1u << PWM_CCMR1_OC1PE_BIT);
    TIM3->CCMR1 |= (1u << PWM_CCMR1_OC2PE_BIT);

    TIM3->CCMR2 &= ~TIM_CCMR2_OC3M;
    TIM3->CCMR2 |= (PWM_MODE_PWM1 << PWM_CCMR2_OC3M_SHIFT);
    TIM3->CCMR2 |= (1u << PWM_CCMR2_OC3PE_BIT);

    TIM3->CCER |= (TIM_CCER_CC1E | TIM_CCER_CC2E | TIM_CCER_CC3E);
    TIM3->CR1 |= TIM_CR1_CEN;
}

/***********************************************************************
 * @fn      - pwm_set_duty_percent
 * @brief   - Set the PWM duty cycle (LED brightness) of all 3 LED
 *            channels to the same value.
 * @param   - u1_percent : duty cycle, range 0-100
 * @return  - void
 ************************************************************************/
void pwm_set_duty_percent(uint8_t u1_percent)
{
    uint16_t u2t_ccrValue;

    if (u1_percent <= PWM_DUTY_MAX_PERCENT)
    {
        u2t_ccrValue = (uint16_t)(((uint32_t)PWM_ARR_VALUE * u1_percent) / PWM_DUTY_MAX_PERCENT);
        TIM3->CCR1 = u2t_ccrValue;
        TIM3->CCR2 = u2t_ccrValue;
        TIM3->CCR3 = u2t_ccrValue;
    }
    else
    {
        /* No action: invalid duty cycle, keep previous value */
    }
}

/* Private functions ----------------------------------------------------*/

/***********************************************************************
 * @fn      - pwm_configure_gpio
 * @brief   - Configure one pin as an alternate-function output routed
 *            to TIM3.
 * @param   - px_port : GPIO port base address
 *           - u1_pin  : pin number
 * @return  - void
 ************************************************************************/
static void pwm_configure_gpio(GPIO_TypeDef *px_port, uint8_t u1_pin)
{
    uint32_t u4t_moderShift = (uint32_t)u1_pin * PWM_MODER_BITS_PER_PIN;
    uint32_t u4t_afrIndex = (uint32_t)u1_pin / 8u;
    uint32_t u4t_afrShift = ((uint32_t)u1_pin % 8u) * PWM_AFR_BITS_PER_PIN;

    px_port->MODER &= ~(0x3u << u4t_moderShift);
    px_port->MODER |= (PWM_MODE_ALT_FUNC << u4t_moderShift);
    px_port->AFR[u4t_afrIndex] &= ~(0xFu << u4t_afrShift);
    px_port->AFR[u4t_afrIndex] |= (PWM_AF_TIM3 << u4t_afrShift);
}
